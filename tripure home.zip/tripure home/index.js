function show(){
    let get=document.getElementById("getid")
    get.style.display="block";
}
function hide(){
    let get=document.getElementById("getid")
    get.style.display="none";
}